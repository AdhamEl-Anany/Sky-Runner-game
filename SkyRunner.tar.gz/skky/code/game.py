"""
Sky Runner 🚀

A simple 2D endless runner game built with Python and Pygame.
Fly your plane, avoid obstacles, and beat your high score!

Features:
- Smooth 2D gameplay with gravity and jump mechanics
- Infinite scrolling background and ground
- Randomly generated obstacles
- Score tracking and high score saving
- Background music and sound effects
- Responsive window scaling

Controls:
- Mouse Click / Tap → Make the plane jump
- ESC / Window Close → Exit the game

Requirements:
    - Python 3.10+
    - Pygame 2.6+
    - Assets folder structure:
        graphics/
            environment/
            plane/
            obstacles/
            ui/
        sounds/
        font/

Developer:
Adham El-Anany
"""


import pygame, sys, time, os
from settings import *
from sprites import BG, Ground, Plane, Obstacle

BASE_DIR = os.path.dirname(os.path.dirname(__file__))

def resource_path(*path_parts):
    return os.path.join(BASE_DIR, *path_parts)

class Game:
    def __init__(self):
        pygame.init()
        self.display_surface = pygame.display.set_mode(
        (WINDOW_WIDTH, WINDOW_HEIGHT), pygame.RESIZABLE | pygame.SCALED)
        pygame.display.set_caption('Sky Runner')

        icon = pygame.image.load(resource_path("graphics", "ui" , "icon.jpeg"))
        pygame.display.set_icon(icon)

        self.clock = pygame.time.Clock()
        self.active = True

        self.all_sprites = pygame.sprite.Group()
        self.collision_sprites = pygame.sprite.Group()

        bg_height = pygame.image.load(resource_path("graphics", "environment", "background.png")).get_height()
        self.scale_factor = WINDOW_HEIGHT / bg_height
        BG(self.all_sprites, self.scale_factor)
        Ground([self.all_sprites, self.collision_sprites], self.scale_factor)

        self.Plane = Plane(self.all_sprites, self.scale_factor / 1.7)

        self.obstacle_timer = pygame.USEREVENT + 1
        pygame.time.set_timer(self.obstacle_timer, 1400)

        self.font = pygame.font.Font(resource_path("graphics", "font", "BD_Cartoon_Shout.ttf"), 30)
        self.test_font = pygame.font.Font(resource_path("graphics", "font", "BD_Cartoon_Shout.ttf"), 30)
        self.made_by_font = pygame.font.Font(resource_path("graphics", "font", "BD_Cartoon_Shout.ttf"), 23)

        self.score = 0
        self.start_offset = 0

        self.menu_surf = pygame.image.load(resource_path("graphics", "ui", "menu.png")).convert_alpha()
        self.menu_rect = self.menu_surf.get_rect(center=(WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2))

        self.music = pygame.mixer.Sound(resource_path("sounds", "music.wav"))
        self.music.set_volume(0.7)
        self.music.play(loops=-1)

        high_score_file = resource_path("high_score.txt")
        try:
            with open(high_score_file, "r") as file:
                content = file.read().strip()
            self.high_score_value = int(content) if content else 0
        except FileNotFoundError:
            self.high_score_value = 0

    def collisions(self):
        if pygame.sprite.spritecollide(self.Plane, self.collision_sprites, False, pygame.sprite.collide_mask) \
                or self.Plane.rect.top <= 0:
            for sprite in self.collision_sprites.sprites():
                if sprite.sprite_type == 'obstacle':
                    sprite.kill()
            self.active = False
            self.Plane.kill()

    def display_score(self):
        if self.active:
            self.score = (pygame.time.get_ticks() - self.start_offset) // 1000
            score_surf = self.font.render(f"score : {self.score}", True, 'black')
            score_rect = score_surf.get_rect(midtop=(WINDOW_WIDTH / 2, WINDOW_HEIGHT/10))
            self.display_surface.blit(score_surf, score_rect)

    def run(self):
        last_time = time.time()
        while True:
            dt = time.time() - last_time
            last_time = time.time()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.active:
                        self.Plane.jump()
                    else:
                        self.Plane = Plane(self.all_sprites, self.scale_factor / 1.7)
                        self.active = True
                        self.start_offset = pygame.time.get_ticks()

                if event.type == self.obstacle_timer and self.active:
                    Obstacle([self.all_sprites, self.collision_sprites], self.scale_factor * 1.1)

            self.display_surface.fill('black')
            self.all_sprites.update(dt)
            self.all_sprites.draw(self.display_surface)
            self.display_score()

            if self.active:
                self.collisions()
                if self.score > self.high_score_value:
                    self.high_score_value = self.score
                    with open(resource_path("high_score.txt"), "w") as file:
                        file.write(str(self.high_score_value))
            else:
                self.display_surface.blit(self.menu_surf, self.menu_rect)
                game_name = self.test_font.render('Sky Runner game', False, 'black')
                game_name_rect = game_name.get_rect(center=(WINDOW_WIDTH/2, 60))
                score_message = self.test_font.render(f'Your score: {self.score}', False, 'black')
                score_message_rect = score_message.get_rect(center=(WINDOW_WIDTH/2, 300))
                high_score_surface = self.test_font.render(f"High Score: {self.high_score_value}", False, (200,70,40))
                high_score_rect = high_score_surface.get_rect(center=(WINDOW_WIDTH/2, 550))
                creator_name = self.made_by_font.render(f'Developed by Adham El-Anany', False, 'black')
                creator_name_rect = creator_name.get_rect(center=(WINDOW_WIDTH/2, 700))

                self.display_surface.blit(game_name, game_name_rect)
                self.display_surface.blit(creator_name, creator_name_rect)
                self.display_surface.blit(high_score_surface, high_score_rect)
                self.display_surface.blit(score_message, score_message_rect)

            pygame.display.update()
            self.clock.tick(FRAMERATE)


if __name__ == '__main__':
    game = Game()
    game.run()